from app import create_app, db
from models.config import SystemConfig

app = create_app('development')

with app.app_context():
    configs = {
        'mail_verification_enabled': SystemConfig.get('mail_verification_enabled'),
        'require_email_verification': SystemConfig.get('require_email_verification'),
        'create_system_account': SystemConfig.get('create_system_account'),
        'mail_server': SystemConfig.get('mail_server'),
        'mail_username': SystemConfig.get('mail_username'),
    }
    
    print("当前配置状态：")
    print("-" * 40)
    for key, value in configs.items():
        print(f"{key}: {value}")
