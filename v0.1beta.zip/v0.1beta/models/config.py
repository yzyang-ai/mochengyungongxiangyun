from datetime import datetime
from app import db

class SystemConfig(db.Model):
    __tablename__ = 'system_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False, index=True)
    value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(256), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    SITE_NAME = 'site_name'
    SITE_DESCRIPTION = 'site_description'
    ALLOW_REGISTRATION = 'allow_registration'
    REQUIRE_EMAIL_VERIFICATION = 'require_email_verification'
    MAX_LOGIN_ATTEMPTS = 'max_login_attempts'
    SESSION_LIFETIME = 'session_lifetime'
    DEFAULT_USER_ROLE = 'default_user_role'
    MAIL_VERIFICATION_ENABLED = 'mail_verification_enabled'
    CREATE_SYSTEM_ACCOUNT = 'create_system_account'
    MAIL_SERVER = 'mail_server'
    MAIL_PORT = 'mail_port'
    MAIL_USE_TLS = 'mail_use_tls'
    MAIL_USERNAME = 'mail_username'
    MAIL_PASSWORD = 'mail_password'
    MAIL_DEFAULT_SENDER = 'mail_default_sender'
    
    def __repr__(self):
        return f'<SystemConfig {self.key}>'
    
    @staticmethod
    def get(key, default=None):
        config = SystemConfig.query.filter_by(key=key).first()
        return config.value if config else default
    
    @staticmethod
    def set(key, value, description=None):
        config = SystemConfig.query.filter_by(key=key).first()
        if config:
            config.value = value
            if description:
                config.description = description
        else:
            config = SystemConfig(key=key, value=value, description=description)
            db.session.add(config)
        db.session.commit()
        return config
    
    @staticmethod
    def init_defaults():
        defaults = {
            SystemConfig.SITE_NAME: ('陌城云共享云电脑管理平台', '网站名称'),
            SystemConfig.SITE_DESCRIPTION: ('专业的云电脑服务管理平台', '网站描述'),
            SystemConfig.ALLOW_REGISTRATION: ('true', '是否允许新用户注册'),
            SystemConfig.REQUIRE_EMAIL_VERIFICATION: ('false', '是否要求邮箱验证'),
            SystemConfig.MAX_LOGIN_ATTEMPTS: ('5', '最大登录尝试次数'),
            SystemConfig.SESSION_LIFETIME: ('24', '会话有效期(小时)'),
            SystemConfig.DEFAULT_USER_ROLE: ('user', '新用户默认角色'),
            SystemConfig.MAIL_VERIFICATION_ENABLED: ('true', '是否启用邮件验证'),
            SystemConfig.CREATE_SYSTEM_ACCOUNT: ('false', '是否在注册时创建系统账号'),
            SystemConfig.MAIL_SERVER: ('smtp.qq.com', 'SMTP服务器地址'),
            SystemConfig.MAIL_PORT: ('587', 'SMTP端口'),
            SystemConfig.MAIL_USE_TLS: ('true', '是否使用TLS'),
            SystemConfig.MAIL_USERNAME: ('', 'SMTP用户名(邮箱)'),
            SystemConfig.MAIL_PASSWORD: ('', 'SMTP密码或授权码'),
            SystemConfig.MAIL_DEFAULT_SENDER: ('系统管理员 <>', '默认发件人'),
        }
        for key, (value, desc) in defaults.items():
            if not SystemConfig.get(key):
                SystemConfig.set(key, value, desc)
    
    def to_dict(self):
        return {
            'key': self.key,
            'value': self.value,
            'description': self.description,
            'updated_at': self.updated_at.isoformat()
        }

class RegistrationField(db.Model):
    __tablename__ = 'registration_fields'
    
    id = db.Column(db.Integer, primary_key=True)
    field_name = db.Column(db.String(50), unique=True, nullable=False)
    display_name = db.Column(db.String(64), nullable=False)
    field_type = db.Column(db.String(20), default='text')
    required = db.Column(db.Boolean, default=True)
    placeholder = db.Column(db.String(128), nullable=True)
    options = db.Column(db.Text, nullable=True)
    sort_order = db.Column(db.Integer, default=0)
    enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    TYPE_TEXT = 'text'
    TYPE_EMAIL = 'email'
    TYPE_PHONE = 'phone'
    TYPE_SELECT = 'select'
    TYPE_TEXTAREA = 'textarea'
    
    def __repr__(self):
        return f'<RegistrationField {self.field_name}>'
    
    @staticmethod
    def get_enabled_fields():
        return RegistrationField.query.filter_by(enabled=True).order_by(RegistrationField.sort_order).all()
    
    @staticmethod
    def init_default_fields():
        defaults = [
            {'field_name': 'real_name', 'display_name': '真实姓名', 'field_type': 'text', 'required': True},
            {'field_name': 'company', 'display_name': '公司名称', 'field_type': 'text', 'required': False},
        ]
        for field_data in defaults:
            if not RegistrationField.query.filter_by(field_name=field_data['field_name']).first():
                field = RegistrationField(**field_data)
                db.session.add(field)
        db.session.commit()
    
    def to_dict(self):
        return {
            'id': self.id,
            'field_name': self.field_name,
            'display_name': self.display_name,
            'field_type': self.field_type,
            'required': self.required,
            'placeholder': self.placeholder,
            'options': self.options,
            'sort_order': self.sort_order,
            'enabled': self.enabled
        }
