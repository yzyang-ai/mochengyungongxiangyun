from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default='user')
    status = db.Column(db.String(20), default='active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    email_verified = db.Column(db.Boolean, default=False)
    login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)
    
    profile = db.relationship('UserProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    logs = db.relationship('Log', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        return self.role == 'admin'
    
    def is_active(self):
        return self.status == 'active'
    
    def can_login(self):
        if self.status != 'active':
            return False, '账户已被禁用'
        if self.is_locked():
            return False, '账户已被锁定'
        return True, '可以登录'
    
    def is_locked(self):
        if self.locked_until and self.locked_until > datetime.utcnow():
            return True
        return False
    
    def lock(self, minutes=30):
        from datetime import timedelta
        self.locked_until = datetime.utcnow() + timedelta(minutes=minutes)
        db.session.commit()
    
    def unlock(self):
        self.locked_until = None
        self.login_attempts = 0
        db.session.commit()
    
    def record_login(self, success=True):
        if success:
            self.last_login = datetime.utcnow()
            self.login_attempts = 0
            self.locked_until = None
        else:
            self.login_attempts += 1
            from config import config
            max_attempts = config['development'].MAX_LOGIN_ATTEMPTS if hasattr(config, 'development') else 5
            if self.login_attempts >= max_attempts:
                self.lock(30)
        db.session.commit()
    
    def to_dict(self, include_email=True):
        data = {
            'id': self.id,
            'username': self.username,
            'role': self.role,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'email_verified': self.email_verified
        }
        if include_email:
            data['email'] = self.email
        if self.profile:
            data['profile'] = self.profile.to_dict()
        return data

class UserProfile(db.Model):
    __tablename__ = 'user_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    real_name = db.Column(db.String(64), nullable=True)
    company = db.Column(db.String(128), nullable=True)
    position = db.Column(db.String(64), nullable=True)
    custom_fields = db.Column(db.Text, default='{}')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserProfile {self.user_id}>'
    
    def to_dict(self):
        import json
        try:
            custom = json.loads(self.custom_fields)
        except:
            custom = {}
        return {
            'real_name': self.real_name,
            'company': self.company,
            'position': self.position,
            'custom_fields': custom
        }
    
    def update_custom_field(self, key, value):
        import json
        try:
            custom = json.loads(self.custom_fields)
        except:
            custom = {}
        custom[key] = value
        self.custom_fields = json.dumps(custom, ensure_ascii=False)
        db.session.commit()
