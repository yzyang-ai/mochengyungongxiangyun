from datetime import datetime
from app import db

class Log(db.Model):
    __tablename__ = 'logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    action = db.Column(db.String(50), nullable=False, index=True)
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.String(256), nullable=True)
    details = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='success')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    LOGIN = 'login'
    LOGOUT = 'logout'
    LOGIN_FAILED = 'login_failed'
    REGISTER = 'register'
    PASSWORD_CHANGE = 'password_change'
    PASSWORD_RESET = 'password_reset'
    PROFILE_UPDATE = 'profile_update'
    EMAIL_VERIFY = 'email_verify'
    ADMIN_ACTION = 'admin_action'
    SYSTEM = 'system'
    
    def __repr__(self):
        return f'<Log {self.action} - {self.created_at}>'
    
    @property
    def formatted_details(self):
        if self.details:
            import json
            try:
                return json.dumps(json.loads(self.details), indent=2, ensure_ascii=False)
            except:
                return self.details
        return ''
    
    @staticmethod
    def log(user_id, action, ip_address=None, user_agent=None, details=None, status='success'):
        log = Log(
            user_id=user_id,
            action=action,
            ip_address=ip_address,
            user_agent=user_agent,
            details=details,
            status=status
        )
        db.session.add(log)
        db.session.commit()
        return log
    
    @staticmethod
    def get_recent_logs(limit=100, action=None, user_id=None, start_date=None, end_date=None):
        query = Log.query
        if action:
            query = query.filter_by(action=action)
        if user_id:
            query = query.filter_by(user_id=user_id)
        if start_date:
            query = query.filter(Log.created_at >= start_date)
        if end_date:
            query = query.filter(Log.created_at <= end_date)
        return query.order_by(Log.created_at.desc()).limit(limit).all()
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action': self.action,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'details': self.details,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }
