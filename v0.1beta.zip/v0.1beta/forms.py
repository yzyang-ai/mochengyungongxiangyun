from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, Regexp, Optional
from models.user import User

class LoginForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired('请输入用户名')])
    password = PasswordField('密码', validators=[DataRequired('请输入密码')])
    remember = BooleanField('记住我')
    submit = SubmitField('登录')

class RegisterForm(FlaskForm):
    username = StringField('用户名', validators=[
        DataRequired('请输入用户名'),
        Length(min=3, max=20, message='用户名长度必须在3-20个字符之间'),
        Regexp(r'^[a-zA-Z0-9_]+$', message='用户名只能包含字母、数字和下划线')
    ])
    email = StringField('邮箱', validators=[
        DataRequired('请输入邮箱'),
        Email('请输入有效的邮箱地址')
    ])
    password = PasswordField('密码', validators=[
        DataRequired('请输入密码'),
        Length(min=8, message='密码长度至少8位'),
        Regexp(r'.*[A-Z].*', message='密码必须包含大写字母'),
        Regexp(r'.*[a-z].*', message='密码必须包含小写字母'),
        Regexp(r'.*\d.*', message='密码必须包含数字'),
        Regexp(r'.*[!@#$%^&*(),.?":{}|<>\-_;].*', message='密码必须包含特殊字符')
    ])
    confirm_password = PasswordField('确认密码', validators=[
        DataRequired('请确认密码'),
        EqualTo('password', message='两次输入的密码不一致')
    ])
    submit = SubmitField('注册')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('用户名已被注册')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('邮箱已被注册')

class ChangePasswordForm(FlaskForm):
    old_password = PasswordField('原密码', validators=[DataRequired('请输入原密码')])
    new_password = PasswordField('新密码', validators=[
        DataRequired('请输入新密码'),
        Length(min=8, message='密码长度至少8位'),
        Regexp(r'.*[A-Z].*', message='密码必须包含大写字母'),
        Regexp(r'.*[a-z].*', message='密码必须包含小写字母'),
        Regexp(r'.*\d.*', message='密码必须包含数字'),
        Regexp(r'.*[!@#$%^&*(),.?":{}|<>\-_;].*', message='密码必须包含特殊字符')
    ])
    confirm_password = PasswordField('确认新密码', validators=[
        DataRequired('请确认新密码'),
        EqualTo('new_password', message='两次输入的密码不一致')
    ])
    submit = SubmitField('修改密码')

class ForgotPasswordForm(FlaskForm):
    email = StringField('邮箱', validators=[
        DataRequired('请输入邮箱'),
        Email('请输入有效的邮箱地址')
    ])
    submit = SubmitField('发送验证码')

class VerifyCodeForm(FlaskForm):
    code = StringField('验证码', validators=[
        DataRequired('请输入验证码'),
        Length(min=6, max=6, message='验证码必须是6位数字')
    ])
    submit = SubmitField('验证')

class ResetPasswordForm(FlaskForm):
    code = StringField('验证码', validators=[
        DataRequired('请输入验证码'),
        Length(min=6, max=6, message='验证码必须是6位数字')
    ])
    password = PasswordField('新密码', validators=[
        DataRequired('请输入新密码'),
        Length(min=8, message='密码长度至少8位'),
        Regexp(r'.*[A-Z].*', message='密码必须包含大写字母'),
        Regexp(r'.*[a-z].*', message='密码必须包含小写字母'),
        Regexp(r'.*\d.*', message='密码必须包含数字'),
        Regexp(r'.*[!@#$%^&*(),.?":{}|<>\-_;].*', message='密码必须包含特殊字符')
    ])
    confirm_password = PasswordField('确认新密码', validators=[
        DataRequired('请确认新密码'),
        EqualTo('password', message='两次输入的密码不一致')
    ])
    submit = SubmitField('重置密码')

class ProfileForm(FlaskForm):
    real_name = StringField('真实姓名', validators=[DataRequired('请输入真实姓名')])
    company = StringField('公司名称', validators=[Optional()])
    position = StringField('职位', validators=[Optional()])
    submit = SubmitField('保存修改')

class AdminUserForm(FlaskForm):
    username = StringField('用户名', validators=[
        DataRequired('请输入用户名'),
        Length(min=3, max=20, message='用户名长度必须在3-20个字符之间')
    ])
    email = StringField('邮箱', validators=[
        DataRequired('请输入邮箱'),
        Email('请输入有效的邮箱地址')
    ])
    role = SelectField('角色', choices=[('user', '普通用户'), ('admin', '管理员')])
    status = SelectField('状态', choices=[('active', '正常'), ('banned', '禁用')])
    submit = SubmitField('保存')

class RegistrationFieldForm(FlaskForm):
    field_name = StringField('字段名', validators=[
        DataRequired('请输入字段名'),
        Regexp(r'^[a-zA-Z_][a-zA-Z0-9_]*$', message='字段名只能包含字母、数字和下划线，且以字母或下划线开头')
    ])
    display_name = StringField('显示名称', validators=[DataRequired('请输入显示名称')])
    field_type = SelectField('字段类型', choices=[
        ('text', '文本'),
        ('email', '邮箱'),
        ('phone', '手机号'),
        ('textarea', '多行文本')
    ])
    required = BooleanField('必填')
    placeholder = StringField('占位符', validators=[Optional()])
    sort_order = StringField('排序', validators=[Optional()], default='0')
    submit = SubmitField('保存')
