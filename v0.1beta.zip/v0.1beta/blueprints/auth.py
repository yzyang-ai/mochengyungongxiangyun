from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
import subprocess
import platform
from app import db
from models.user import User, UserProfile
from models.log import Log
from models.config import SystemConfig, RegistrationField
from utils.email import EmailService, VerificationCode
from utils.decorators import log_action
from utils.helpers import validate_email, validate_password_strength, get_client_ip, get_user_agent
from forms import LoginForm, RegisterForm, ChangePasswordForm, ForgotPasswordForm, ResetPasswordForm, VerifyCodeForm

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user:
            can_login, message = user.can_login()
            if not can_login:
                flash(message, 'danger')
                Log.log(user.id, Log.LOGIN_FAILED, get_client_ip(), get_user_agent(), message, 'failed')
                return render_template('auth/login.html', form=form)
            
            if user.check_password(form.password.data):
                mail_verify_enabled = SystemConfig.get('mail_verification_enabled') == 'true'
                require_email_verify = SystemConfig.get('require_email_verification') == 'true'
                
                need_verify = (mail_verify_enabled or require_email_verify)
                is_admin = user.role == 'admin'
                
                if need_verify and not user.email_verified and not is_admin:
                    session['pending_verification_email'] = user.email
                    flash('请先完成邮箱验证才能登录', 'warning')
                    Log.log(user.id, Log.LOGIN_FAILED, get_client_ip(), get_user_agent(), '邮箱未验证', 'failed')
                    return redirect(url_for('auth.verify_email'))
                
                login_user(user, remember=form.remember.data)
                user.record_login(success=True)
                Log.log(user.id, Log.LOGIN, get_client_ip(), get_user_agent(), '登录成功')
                
                flash('登录成功！', 'success')
                next_page = request.args.get('next')
                return redirect(next_page) if next_page else redirect(url_for('index'))
            else:
                user.record_login(success=False)
                flash('用户名或密码错误', 'danger')
                Log.log(None, Log.LOGIN_FAILED, get_client_ip(), get_user_agent(), f'密码错误: {form.username.data}')
        else:
            flash('用户名或密码错误', 'danger')
            Log.log(None, Log.LOGIN_FAILED, get_client_ip(), get_user_agent(), f'用户不存在: {form.username.data}')
    
    return render_template('auth/login.html', form=form)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if SystemConfig.get('allow_registration') != 'true':
        flash('系统当前禁止新用户注册', 'warning')
        return redirect(url_for('auth.login'))
    
    registration_fields = RegistrationField.get_enabled_fields()
    form = RegisterForm()
    
    if form.validate_on_submit():
        if User.query.filter_by(username=form.username.data).first():
            flash('用户名已存在', 'danger')
            return render_template('auth/register.html', form=form, fields=registration_fields)
        
        if User.query.filter_by(email=form.email.data).first():
            flash('邮箱已被注册', 'danger')
            return render_template('auth/register.html', form=form, fields=registration_fields)
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            role=SystemConfig.get('default_user_role', 'user'),
            status='active'
        )
        user.set_password(form.password.data)
        
        db.session.add(user)
        db.session.commit()
        
        profile_data = {}
        for field in registration_fields:
            field_value = getattr(form, field.field_name, None)
            if field_value:
                profile_data[field.field_name] = getattr(form, field.field_name).data
        
        profile = UserProfile(user_id=user.id, custom_fields=str(profile_data))
        db.session.add(profile)
        db.session.commit()
        
        success, msg = create_system_account(user.username, form.password.data)
        if SystemConfig.get('create_system_account') == 'true':
            current_app.logger.info(f'系统账号创建: {msg}')
        
        mail_verify_enabled = SystemConfig.get('mail_verification_enabled') == 'true'
        require_email_verify = SystemConfig.get('require_email_verification') == 'true'
        
        if mail_verify_enabled or require_email_verify:
            code = VerificationCode.generate_and_save(user.email, VerificationCode.TYPE_REGISTER)
            EmailService.send_verification_email(user.email, code, 'register')
            session['pending_verification_email'] = user.email
            flash('注册成功！请查收邮件完成验证', 'success')
            return redirect(url_for('auth.verify_email'))
        else:
            EmailService.send_welcome_email(user)
            Log.log(user.id, Log.REGISTER, get_client_ip(), get_user_agent(), '注册成功')
            flash('注册成功！请登录', 'success')
            return redirect(url_for('auth.login'))
    
    for field in registration_fields:
        if field.field_name not in form._fields:
            setattr(form, field.field_name, None)
    
    return render_template('auth/register.html', form=form, fields=registration_fields)

@auth_bp.route('/verify-email', methods=['GET', 'POST'])
def verify_email():
    pending_email = session.get('pending_verification_email')
    if not pending_email:
        flash('无待验证邮箱', 'warning')
        return redirect(url_for('index'))
    
    form = VerifyCodeForm()
    if form.validate_on_submit():
        success, message = VerificationCode.verify(pending_email, form.code.data, VerificationCode.TYPE_REGISTER)
        if success:
            user = User.query.filter_by(email=pending_email).first()
            if user:
                user.email_verified = True
                db.session.commit()
                session.pop('pending_verification_email', None)
                EmailService.send_welcome_email(user)
                Log.log(user.id, Log.EMAIL_VERIFY, get_client_ip(), get_user_agent(), '邮箱验证成功')
                flash('邮箱验证成功！请登录', 'success')
                return redirect(url_for('auth.login'))
        else:
            flash(message, 'danger')
    
    return render_template('auth/verify_email.html', form=form, email=pending_email)

@auth_bp.route('/logout')
@login_required
def logout():
    Log.log(current_user.id, Log.LOGOUT, get_client_ip(), get_user_agent(), '用户退出')
    logout_user()
    flash('已退出登录', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            code = VerificationCode.generate_and_save(user.email, VerificationCode.TYPE_FORGOT)
            EmailService.send_verification_email(user.email, code, 'forgot')
            session['reset_password_email'] = user.email
            flash('验证码已发送到您的邮箱', 'success')
            return redirect(url_for('auth.reset_password'))
        else:
            flash('该邮箱未注册', 'danger')
    
    return render_template('auth/forgot_password.html', form=form)

@auth_bp.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    reset_email = session.get('reset_password_email')
    if not reset_email:
        flash('无效的重置请求', 'warning')
        return redirect(url_for('auth.forgot_password'))
    
    form = ResetPasswordForm()
    if form.validate_on_submit():
        success, message = VerificationCode.verify(reset_email, form.code.data, VerificationCode.TYPE_FORGOT)
        if success:
            user = User.query.filter_by(email=reset_email).first()
            if user:
                user.set_password(form.password.data)
                db.session.commit()
                EmailService.send_password_changed_notification(user.email)
                session.pop('reset_password_email', None)
                Log.log(user.id, Log.PASSWORD_RESET, get_client_ip(), get_user_agent(), '密码重置成功')
                flash('密码重置成功！请使用新密码登录', 'success')
                return redirect(url_for('auth.login'))
        else:
            flash(message, 'danger')
    
    return render_template('auth/reset_password.html', form=form)

@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.old_password.data):
            flash('原密码错误', 'danger')
            return render_template('auth/change_password.html', form=form)
        
        valid, message = validate_password_strength(form.new_password.data)
        if not valid:
            flash(message, 'danger')
            return render_template('auth/change_password.html', form=form)
        
        current_user.set_password(form.new_password.data)
        db.session.commit()
        EmailService.send_password_changed_notification(current_user.email)
        Log.log(current_user.id, Log.PASSWORD_CHANGE, get_client_ip(), get_user_agent(), '密码修改成功')
        flash('密码修改成功！', 'success')
        return redirect(url_for('user.profile'))
    
    return render_template('auth/change_password.html', form=form)

def create_system_account(username, password):
    enable_system_accounts = SystemConfig.get('create_system_account', 'false')
    if enable_system_accounts != 'true':
        return True, '系统账号功能未启用'
    
    try:
        if platform.system() == 'Windows':
            return create_windows_user(username, password)
        else:
            return create_linux_user(username, password)
    except Exception as e:
        current_app.logger.error(f'创建系统账号失败: {e}')
        return False, f'创建系统账号失败: {str(e)}'

def create_windows_user(username, password):
    try:
        import win32net
        import win32netcon
        
        user_info = {
            'name': username,
            'password': password,
            'priv': win32netcon.USER_PRIV_USER,
            'home_dir': None,
            'comment': '陌城云系统用户',
            'flags': win32netcon.UF_NORMAL_ACCOUNT | win32netcon.UF_SCRIPT,
            'script_path': None
        }
        
        try:
            win32net.NetUserAdd(None, 3, [user_info])
            return True, f'Windows用户 {username} 创建成功'
        except:
            return True, f'Windows用户 {username} 已存在'
    except ImportError:
        return True, 'Windows功能需要pywin32库，跳过系统账号创建'
    except Exception as e:
        return False, str(e)

def create_linux_user(username, password):
    try:
        import pwd
        
        try:
            pwd.getpwnam(username)
            return True, f'Linux用户 {username} 已存在'
        except KeyError:
            pass
        
        cmd = f'echo "{username}:{password}" | chpasswd'
        result = subprocess.run(['sh', '-c', cmd], capture_output=True, text=True)
        
        if result.returncode != 0:
            try:
                subprocess.run(['useradd', '-m', '-p', password, username], capture_output=True, text=True)
            except:
                pass
        
        return True, f'Linux用户 {username} 创建指令已执行'
    except Exception as e:
        return False, str(e)
