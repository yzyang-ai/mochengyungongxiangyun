from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, jsonify
from flask_login import login_required, current_user
from app import db
from models.user import User
from models.log import Log
from models.config import SystemConfig, RegistrationField
from utils.helpers import get_client_ip, get_user_agent, format_datetime
from utils.decorators import admin_required
from utils.email import EmailService

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    from datetime import datetime, timedelta
    
    today = datetime.utcnow().date()
    today_start = datetime.combine(today, datetime.min.time())
    
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(status='active').count(),
        'banned_users': User.query.filter_by(status='banned').count(),
        'today_registrations': User.query.filter(User.created_at >= today_start).count(),
        'today_logins': Log.query.filter(Log.action == Log.LOGIN, Log.created_at >= today_start).count(),
        'total_logs': Log.query.count()
    }
    
    recent_logs = Log.query.order_by(Log.created_at.desc()).limit(20).all()
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    return render_template('admin/dashboard.html',
                         stats=stats,
                         logs=recent_logs,
                         users=recent_users)

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    search = request.args.get('search', '')
    status_filter = request.args.get('status')
    role_filter = request.args.get('role')
    
    query = User.query
    
    if search:
        query = query.filter(
            db.or_(
                User.username.contains(search),
                User.email.contains(search)
            )
        )
    if status_filter:
        query = query.filter_by(status=status_filter)
    if role_filter:
        query = query.filter_by(role=role_filter)
    
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/users.html',
                         users=pagination.items,
                         pagination=pagination,
                         page=page,
                         search=search,
                         status_filter=status_filter,
                         role_filter=role_filter)

@admin_bp.route('/users/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_user():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'user')
        status = request.form.get('status', 'active')
        
        if not all([username, email, password]):
            flash('用户名、邮箱和密码为必填项', 'danger')
            return redirect(url_for('admin.add_user'))
        
        if User.query.filter_by(username=username).first():
            flash('用户名已存在', 'danger')
            return redirect(url_for('admin.add_user'))
        
        if User.query.filter_by(email=email).first():
            flash('邮箱已被注册', 'danger')
            return redirect(url_for('admin.add_user'))
        
        user = User(
            username=username,
            email=email,
            role=role,
            status=status
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        Log.log(current_user.id, Log.ADMIN_ACTION, get_client_ip(), get_user_agent(), 
               f'添加用户: {username}')
        flash(f'用户 {username} 添加成功', 'success')
        return redirect(url_for('admin.users'))
    
    return render_template('admin/user_form.html', action='add')

@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        role = request.form.get('role')
        status = request.form.get('status')
        
        if username != user.username and User.query.filter_by(username=username).first():
            flash('用户名已存在', 'danger')
            return redirect(url_for('admin.edit_user', user_id=user_id))
        
        if email != user.email and User.query.filter_by(email=email).first():
            flash('邮箱已被注册', 'danger')
            return redirect(url_for('admin.edit_user', user_id=user_id))
        
        user.username = username
        user.email = email
        user.role = role
        user.status = status
        
        db.session.commit()
        
        Log.log(current_user.id, Log.ADMIN_ACTION, get_client_ip(), get_user_agent(), 
               f'编辑用户: {username}')
        flash(f'用户 {username} 更新成功', 'success')
        return redirect(url_for('admin.users'))
    
    return render_template('admin/user_form.html', action='edit', user=user)

@admin_bp.route('/users/<int:user_id>/delete')
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if user.id == current_user.id:
        flash('不能删除当前登录的用户', 'danger')
        return redirect(url_for('admin.users'))
    
    username = user.username
    db.session.delete(user)
    db.session.commit()
    
    Log.log(current_user.id, Log.ADMIN_ACTION, get_client_ip(), get_user_agent(), 
           f'删除用户: {username}')
    flash(f'用户 {username} 已删除', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/toggle-status')
@login_required
@admin_required
def toggle_user_status(user_id):
    user = User.query.get_or_404(user_id)
    
    if user.id == current_user.id:
        flash('不能修改当前登录用户的状态', 'danger')
        return redirect(url_for('admin.users'))
    
    user.status = 'banned' if user.status == 'active' else 'active'
    db.session.commit()
    
    action = '禁用' if user.status == 'banned' else '启用'
    Log.log(current_user.id, Log.ADMIN_ACTION, get_client_ip(), get_user_agent(), 
           f'{action}用户: {user.username}')
    flash(f'用户 {user.username} 已{action}', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/registration-fields', methods=['GET', 'POST'])
@login_required
@admin_required
def registration_fields():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            field_name = request.form.get('field_name')
            display_name = request.form.get('display_name')
            field_type = request.form.get('field_type', 'text')
            required = 'required' in request.form
            placeholder = request.form.get('placeholder')
            sort_order = request.form.get('sort_order', 0)
            
            if RegistrationField.query.filter_by(field_name=field_name).first():
                flash('字段名已存在', 'danger')
            else:
                field = RegistrationField(
                    field_name=field_name,
                    display_name=display_name,
                    field_type=field_type,
                    required=required,
                    placeholder=placeholder,
                    sort_order=sort_order
                )
                db.session.add(field)
                db.session.commit()
                flash('字段添加成功', 'success')
        
        elif action == 'update':
            field_id = request.form.get('field_id')
            field = RegistrationField.query.get_or_404(field_id)
            field.display_name = request.form.get('display_name')
            field.field_type = request.form.get('field_type', 'text')
            field.required = 'required' in request.form
            field.placeholder = request.form.get('placeholder')
            field.sort_order = request.form.get('sort_order', 0)
            field.enabled = 'enabled' in request.form
            db.session.commit()
            flash('字段更新成功', 'success')
        
        elif action == 'delete':
            field_id = request.form.get('field_id')
            field = RegistrationField.query.get_or_404(field_id)
            db.session.delete(field)
            db.session.commit()
            flash('字段已删除', 'success')
        
        return redirect(url_for('admin.registration_fields'))
    
    fields = RegistrationField.query.order_by(RegistrationField.sort_order).all()
    return render_template('admin/registration_fields.html', fields=fields)

@admin_bp.route('/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def settings():
    if request.method == 'POST':
        config_keys = [
            'site_name', 'site_description', 'allow_registration',
            'require_email_verification', 'max_login_attempts', 
            'session_lifetime', 'default_user_role', 'mail_verification_enabled',
            'create_system_account', 'mail_server', 'mail_port',
            'mail_use_tls', 'mail_username', 'mail_password', 'mail_default_sender'
        ]
        
        checkbox_keys = ['allow_registration', 'require_email_verification', 
                        'mail_verification_enabled', 'create_system_account', 'mail_use_tls']
        
        for key in config_keys:
            value = request.form.get(key)
            if value is not None:
                if key in checkbox_keys:
                    value = 'false'
                SystemConfig.set(key, value)
        
        flash('系统设置已更新', 'success')
        return redirect(url_for('admin.settings'))
    
    configs = {c.key: c.value for c in SystemConfig.query.all()}
    fields = RegistrationField.query.order_by(RegistrationField.sort_order).all()
    
    return render_template('admin/settings.html', configs=configs, fields=fields)

@admin_bp.route('/test-email', methods=['POST'])
@login_required
@admin_required
def test_email():
    email = request.json.get('email')
    
    if not email:
        return jsonify({'success': False, 'message': '请输入测试邮箱地址'})
    
    try:
        success, message = EmailService.send_test_email(email)
        Log.log(current_user.id, 'admin_action', get_client_ip(), get_user_agent(), f'测试邮件发送至: {email}')
        return jsonify({'success': success, 'message': message})
    except Exception as e:
        current_app.logger.error(f'测试邮件失败: {str(e)}')
        return jsonify({'success': False, 'message': f'测试失败: {str(e)}'})

@admin_bp.route('/logs')
@login_required
@admin_required
def logs():
    page = request.args.get('page', 1, type=int)
    per_page = 30
    
    action_filter = request.args.get('action')
    status_filter = request.args.get('status')
    user_filter = request.args.get('user')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Log.query
    
    if action_filter:
        query = query.filter_by(action=action_filter)
    if status_filter:
        query = query.filter_by(status=status_filter)
    if user_filter:
        query = query.filter_by(user_id=user_filter)
    if start_date:
        from datetime import datetime
        query = query.filter(Log.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        from datetime import datetime
        query = query.filter(Log.created_at <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
    
    pagination = query.order_by(Log.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    users = User.query.all()
    
    return render_template('admin/logs.html',
                         logs=pagination.items,
                         pagination=pagination,
                         page=page,
                         action_filter=action_filter,
                         status_filter=status_filter,
                         user_filter=user_filter,
                         start_date=start_date,
                         end_date=end_date,
                         users=users,
                         log_actions=Log.__dict__.items())

@admin_bp.route('/logs/export')
@login_required
@admin_required
def export_logs():
    import csv
    from io import StringIO
    from flask import Response
    
    logs = Log.query.order_by(Log.created_at.desc()).all()
    
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', '用户ID', '操作', 'IP地址', 'User Agent', '状态', '详情', '创建时间'])
    
    for log in logs:
        writer.writerow([
            log.id,
            log.user_id or '',
            log.action,
            log.ip_address or '',
            log.user_agent or '',
            log.status,
            log.details or '',
            format_datetime(log.created_at)
        ])
    
    response = Response(output.getvalue(), mimetype='text/csv')
    response.headers.set('Content-Disposition', 'attachment', filename=f'logs_{format_datetime(datetime.utcnow(), "%Y%m%d_%H%M%S")}.csv')
    return response
