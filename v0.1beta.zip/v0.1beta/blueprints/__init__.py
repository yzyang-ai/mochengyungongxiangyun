from blueprints.auth import auth_bp
from blueprints.user import user_bp
from blueprints.admin import admin_bp

__all__ = ['auth_bp', 'user_bp', 'admin_bp']
