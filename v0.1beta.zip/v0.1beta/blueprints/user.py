from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app import db
from models.user import User, UserProfile
from models.log import Log
from models.config import RegistrationField
from utils.helpers import get_client_ip, get_user_agent, format_datetime

user_bp = Blueprint('user', __name__)

@user_bp.route('/dashboard')
@login_required
def dashboard():
    user_data = current_user.to_dict()
    recent_logs = Log.query.filter_by(user_id=current_user.id).order_by(Log.created_at.desc()).limit(10).all()
    
    return render_template('user/dashboard.html', 
                         user=current_user, 
                         logs=recent_logs,
                         user_data=user_data)

@user_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        try:
            real_name = request.form.get('real_name')
            company = request.form.get('company')
            position = request.form.get('position')
            
            if not real_name:
                flash('真实姓名不能为空', 'danger')
                return redirect(url_for('user.profile'))
            
            custom_fields = {}
            registration_fields = RegistrationField.get_enabled_fields()
            for field in registration_fields:
                if field.field_name not in ['real_name', 'company']:
                    value = request.form.get(field.field_name)
                    if value:
                        custom_fields[field.field_name] = value
            
            if not current_user.profile:
                profile = UserProfile(user_id=current_user.id)
                db.session.add(profile)
                db.session.flush()
            
            current_user.profile.real_name = real_name
            current_user.profile.company = company
            current_user.profile.position = position
            current_user.profile.custom_fields = str(custom_fields)
            
            db.session.commit()
            Log.log(current_user.id, Log.PROFILE_UPDATE, get_client_ip(), get_user_agent(), '个人信息更新')
            flash('个人信息更新成功', 'success')
            return redirect(url_for('user.profile'))
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f'个人信息更新失败: {e}')
            flash('更新失败，请重试', 'danger')
    
    registration_fields = RegistrationField.get_enabled_fields()
    custom_fields = {}
    if current_user.profile:
        try:
            import json
            custom_fields = json.loads(current_user.profile.custom_fields or '{}')
        except:
            custom_fields = {}
    
    return render_template('user/profile.html', 
                         user=current_user, 
                         profile=current_user.profile,
                         custom_fields=custom_fields,
                         fields=registration_fields)

@user_bp.route('/security')
@login_required
def security():
    login_logs = Log.query.filter_by(
        user_id=current_user.id, 
        action=Log.LOGIN
    ).order_by(Log.created_at.desc()).limit(20).all()
    
    return render_template('user/security.html', 
                         user=current_user, 
                         login_logs=login_logs)

@user_bp.route('/logs')
@login_required
def logs():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    action_filter = request.args.get('action')
    status_filter = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Log.query.filter_by(user_id=current_user.id)
    
    if action_filter:
        query = query.filter_by(action=action_filter)
    if status_filter:
        query = query.filter_by(status=status_filter)
    if start_date:
        from datetime import datetime
        query = query.filter(Log.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        from datetime import datetime
        query = query.filter(Log.created_at <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
    
    pagination = query.order_by(Log.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('user/logs.html',
                         logs=pagination.items,
                         pagination=pagination,
                         page=page,
                         action_filter=action_filter,
                         status_filter=status_filter,
                         start_date=start_date,
                         end_date=end_date)

@user_bp.route('/settings')
@login_required
def settings():
    if not current_user.is_admin():
        flash('您没有权限访问此页面', 'warning')
        return redirect(url_for('user.dashboard'))
    return redirect(url_for('admin.settings'))
