from app import create_app, db
from models.user import User
from models.log import Log
from models.config import SystemConfig, RegistrationField

app = create_app('development')

with app.app_context():
    db.create_all()
    
    if not SystemConfig.query.first():
        SystemConfig.init_defaults()
        RegistrationField.init_default_fields()
        print("初始化数据库完成！")
    
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            email='admin@example.com',
            role='admin',
            status='active'
        )
        admin.set_password('Admin@123456')
        db.session.add(admin)
        db.session.commit()
        print("创建管理员账户完成！")
        print("用户名: admin")
        print("密码: Admin@123456")
        print("请及时修改密码！")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
