from app import create_app, db
from models.user import User

app = create_app('development')

with app.app_context():
    admin = User.query.filter_by(username='admin').first()
    
    if admin:
        admin.login_attempts = 0
        admin.locked_until = None
        admin.status = 'active'
        db.session.commit()
        print("✅ 管理员账户已解锁！")
        print(f"   用户名: {admin.username}")
        print(f"   状态: {admin.status}")
        print(f"   锁定状态: {'已锁定' if admin.is_locked() else '已解锁'}")
    else:
        print("❌ 未找到管理员账户")
        print("   请先运行 python run.py 初始化数据库")
