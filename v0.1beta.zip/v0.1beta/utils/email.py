import smtplib
import random
import string
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from flask import current_app
from app import mail, db
from models.log import Log
from models.config import SystemConfig

class EmailService:
    
    @staticmethod
    def generate_verification_code(length=6):
        return ''.join(random.choices(string.digits, k=length))
    
    @staticmethod
    def get_smtp_config():
        return {
            'server': SystemConfig.get('mail_server', current_app.config.get('MAIL_SERVER', 'smtp.qq.com')),
            'port': int(SystemConfig.get('mail_port', current_app.config.get('MAIL_PORT', 587))),
            'use_tls': SystemConfig.get('mail_use_tls', str(current_app.config.get('MAIL_USE_TLS', True))).lower() == 'true',
            'username': SystemConfig.get('mail_username', current_app.config.get('MAIL_USERNAME', '')),
            'password': SystemConfig.get('mail_password', current_app.config.get('MAIL_PASSWORD', '')),
            'sender': SystemConfig.get('mail_default_sender', current_app.config.get('MAIL_DEFAULT_SENDER', '系统管理员'))
        }
    
    @staticmethod
    def send_verification_email(email, code, purpose='verify'):
        """发送验证码邮件"""
        subject_map = {
            'verify': '邮箱验证验证码',
            'register': '注册验证码',
            'forgot': '找回密码验证码',
            'login': '登录验证码'
        }
        subject = subject_map.get(purpose, '验证码')
        
        expiry = SystemConfig.get('verification_code_expiry', current_app.config.get('VERIFICATION_CODE_EXPIRY', 10))
        
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #333;">{subject}</h2>
                <div style="background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
                    <p style="font-size: 16px;">您的验证码是：</p>
                    <p style="font-size: 32px; font-weight: bold; color: #007bff; letter-spacing: 5px;">{code}</p>
                </div>
                <p style="color: #666;">验证码将在 {expiry} 分钟后过期，请尽快使用。</p>
                <p style="color: #666;">如果不是您本人操作，请忽略此邮件。</p>
            </div>
        </body>
        </html>
        """
        
        return EmailService._send_email(email, subject, html_content)
    
    @staticmethod
    def send_welcome_email(user):
        """发送欢迎邮件"""
        site_name = SystemConfig.get('site_name', '陌城云共享云电脑管理平台')
        
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #333;">欢迎加入 {site_name}！</h2>
                <p style="font-size: 16px;">尊敬的 <strong>{user.username}</strong>，您好！</p>
                <p style="color: #666;">感谢您注册成为我们的会员，您的账号已成功创建。</p>
                <p style="color: #666;">现在您可以：</p>
                <ul style="color: #666;">
                    <li>登录管理控制台</li>
                    <li>完善个人资料</li>
                    <li>使用云电脑服务</li>
                </ul>
                <p style="color: #666;">如有疑问，请联系客服。</p>
            </div>
        </body>
        </html>
        """
        
        return EmailService._send_email(user.email, f'欢迎加入{site_name}', html_content)
    
    @staticmethod
    def send_test_email(to_email):
        """发送测试邮件"""
        html_content = """
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #333;">SMTP配置测试</h2>
                <p>这是一封测试邮件，用于验证SMTP配置是否正确。</p>
                <p style="color: #666;">如果您收到此邮件，说明SMTP配置成功！</p>
                <p style="color: #666;">时间：<strong>{time}</strong></p>
            </div>
        </body>
        </html>
        """.format(time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        return EmailService._send_email(to_email, 'SMTP配置测试', html_content)
    
    @staticmethod
    def send_password_changed_notification(email):
        """发送密码修改通知"""
        html_content = """
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #333;">密码已修改</h2>
                <p>您的账户密码已于 <strong>{time}</strong> 修改。</p>
                <p style="color: #666;">如果不是您本人操作，请立即登录并修改密码，或联系客服。</p>
            </div>
        </body>
        </html>
        """.format(time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        return EmailService._send_email(email, '密码修改通知', html_content)
    
    @staticmethod
    def _send_email(to_email, subject, html_content):
        """内部发送邮件方法"""
        try:
            config = EmailService.get_smtp_config()
            
            if not config['username'] or not config['password']:
                current_app.logger.warning('SMTP配置不完整，邮件发送跳过')
                return True, '邮件发送跳过(SMTP未配置)'
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = config['sender']
            msg['To'] = to_email
            
            html_part = MIMEText(html_content, 'html', 'utf-8')
            msg.attach(html_part)
            
            current_app.logger.info(f'尝试连接SMTP: {config["server"]}:{config["port"]}')
            
            if config['use_tls']:
                server = smtplib.SMTP(config['server'], config['port'], timeout=30)
                server.ehlo()
                server.starttls()
                server.ehlo()
            else:
                server = smtplib.SMTP_SSL(config['server'], config['port'], timeout=30)
                server.ehlo()
            
            server.login(config['username'], config['password'])
            server.send_message(msg)
            server.quit()
            
            return True, '邮件发送成功'
        except smtplib.SMTPAuthenticationError as e:
            current_app.logger.error(f'邮件发送失败(认证错误): {str(e)}')
            return True, '验证码已生成(邮件认证失败，请检查用户名密码)'
        except smtplib.SMTPConnectError as e:
            current_app.logger.error(f'邮件发送失败(连接错误): {str(e)}')
            return True, '验证码已生成(连接SMTP失败，请检查服务器地址和端口)'
        except smtplib.SMTPException as e:
            current_app.logger.error(f'邮件发送失败(SMTP错误): {str(e)}')
            return True, '验证码已生成(邮件发送失败)'
        except Exception as e:
            current_app.logger.error(f'邮件发送失败: {str(e)}')
            return True, '验证码已生成(邮件发送失败)'

class VerificationCode(db.Model):
    __tablename__ = 'verification_codes'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False, index=True)
    code = db.Column(db.String(10), nullable=False)
    code_type = db.Column(db.String(20), nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    TYPE_REGISTER = 'register'
    TYPE_FORGOT = 'forgot'
    TYPE_LOGIN = 'login'
    TYPE_VERIFY = 'verify'
    
    def __repr__(self):
        return f'<VerificationCode {self.email} - {self.code}>'
    
    @staticmethod
    def generate_and_save(email, code_type, expiry_minutes=10):
        code = EmailService.generate_verification_code()
        expires_at = datetime.utcnow() + timedelta(minutes=expiry_minutes)
        
        old_codes = VerificationCode.query.filter_by(
            email=email, 
            code_type=code_type, 
            used=False
        ).all()
        for old in old_codes:
            old.used = True
        
        verification = VerificationCode(
            email=email,
            code=code,
            code_type=code_type,
            expires_at=expires_at
        )
        db.session.add(verification)
        db.session.commit()
        
        return code
    
    @staticmethod
    def verify(email, code, code_type):
        verification = VerificationCode.query.filter_by(
            email=email,
            code=code,
            code_type=code_type,
            used=False
        ).first()
        
        if not verification:
            return False, '验证码无效'
        
        if datetime.utcnow() > verification.expires_at:
            return False, '验证码已过期'
        
        verification.used = True
        db.session.commit()
        return True, '验证码正确'
    
    @staticmethod
    def cleanup_expired():
        expired = VerificationCode.query.filter(
            VerificationCode.expires_at < datetime.utcnow()
        ).delete()
        db.session.commit()
        return expired
