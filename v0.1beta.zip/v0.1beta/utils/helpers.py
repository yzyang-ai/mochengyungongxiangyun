import os
import re
import json
import hashlib
import uuid
from datetime import datetime
from flask import current_app, request
from werkzeug.security import check_password_hash

def generate_token(length=32):
    import secrets
    return secrets.token_hex(length)

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    pattern = r'^1[3-9]\d{9}$'
    return re.match(pattern, phone) is not None

def validate_password_strength(password, min_length=8):
    if len(password) < min_length:
        return False, f'密码长度至少{min_length}位'
    if not re.search(r'[A-Z]', password):
        return False, '密码必须包含大写字母'
    if not re.search(r'[a-z]', password):
        return False, '密码必须包含小写字母'
    if not re.search(r'\d', password):
        return False, '密码必须包含数字'
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, '密码必须包含特殊字符'
    return True, '密码强度合格'

def get_client_ip():
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    return request.remote_addr

def get_user_agent():
    return request.user_agent.string if request.user_agent else ''

def format_datetime(dt, format='%Y-%m-%d %H:%M:%S'):
    if isinstance(dt, str):
        return dt
    return dt.strftime(format)

def get_file_extension(filename):
    return os.path.splitext(filename)[1].lower()

def allowed_file(filename, allowed_extensions=None):
    if allowed_extensions is None:
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc', 'docx'}
    return '.' in filename and get_file_extension(filename) in allowed_extensions

def save_upload_file(file, upload_folder, rename=True):
    if file and allowed_file(file.filename):
        if rename:
            filename = f"{uuid.uuid4().hex}{get_file_extension(file.filename)}"
        else:
            filename = file.filename
        filepath = os.path.join(upload_folder, filename)
        file.save(filepath)
        return filename
    return None

def dict_to_json(data):
    return json.dumps(data, ensure_ascii=False, indent=2)

def json_to_dict(json_str):
    try:
        return json.loads(json_str)
    except:
        return {}

def calculate_file_hash(filepath, algorithm='md5'):
    hash_obj = hashlib.new(algorithm)
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            hash_obj.update(chunk)
    return hash_obj.hexdigest()

class PaginationHelper:
    def __init__(self, query, page, per_page, endpoint, **kwargs):
        self.query = query
        self.page = page
        self.per_page = per_page
        self.endpoint = endpoint
        self.kwargs = kwargs
        
    def get_pagination_data(self):
        pagination = self.query.paginate(page=self.page, per_page=self.per_page, error_out=False)
        return {
            'items': pagination.items,
            'has_prev': pagination.has_prev,
            'has_next': pagination.has_next,
            'page': pagination.page,
            'pages': pagination.pages,
            'total': pagination.total,
            'prev_num': pagination.prev_num,
            'next_num': pagination.next_num
        }
    
    def get_page_url(self, page):
        self.kwargs['page'] = page
        from flask import url_for
        return url_for(self.endpoint, **self.kwargs)

class FlashMessages:
    SUCCESS = 'success'
    DANGER = 'danger'
    WARNING = 'warning'
    INFO = 'info'
    
    @staticmethod
    def success(message):
        flash(message, FlashMessages.SUCCESS)
    
    @staticmethod
    def danger(message):
        flash(message, FlashMessages.DANGER)
    
    @staticmethod
    def warning(message):
        flash(message, FlashMessages.WARNING)
    
    @staticmethod
    def info(message):
        flash(message, FlashMessages.INFO)

def get_system_info():
    import platform
    return {
        'platform': platform.system(),
        'platform_version': platform.version(),
        'python_version': platform.python_version(),
        'processor': platform.processor()
    }

class SystemStatus:
    @staticmethod
    def check_disk_space(min_free_mb=100):
        import shutil
        total, used, free = shutil.disk_usage('.')
        free_mb = free // (1024 * 1024)
        return free_mb > min_free_mb, free_mb
    
    @staticmethod
    def check_memory_usage(max_usage_percent=80):
        import psutil
        mem = psutil.virtual_memory()
        return mem.percent < max_usage_percent, mem.percent
    
    @staticmethod
    def get_all_checks():
        disk_ok, disk_space = SystemStatus.check_disk_space()
        mem_ok, mem_usage = SystemStatus.check_memory_usage()
        return {
            'disk': {'ok': disk_ok, 'free_mb': disk_space},
            'memory': {'ok': mem_ok, 'usage_percent': mem_usage},
            'healthy': disk_ok and mem_ok
        }
