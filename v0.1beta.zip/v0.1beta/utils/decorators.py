from functools import wraps
from flask import redirect, url_for, flash, abort, request, current_app
from flask_login import current_user
from app import db
from models.log import Log

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('请先登录', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('请先登录', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        if not current_user.is_admin():
            flash('您没有权限访问此页面', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('请先登录', 'warning')
                return redirect(url_for('auth.login', next=request.url))
            if not current_user.has_permission(permission):
                flash('您没有权限执行此操作', 'danger')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def log_action(action, status='success'):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            result = f(*args, **kwargs)
            try:
                Log.log(
                    user_id=current_user.id if current_user.is_authenticated else None,
                    action=action,
                    ip_address=request.remote_addr,
                    user_agent=request.user_agent.string,
                    details=str(args) + str(kwargs) if status == 'success' else str(result),
                    status=status
                )
            except Exception as e:
                current_app.logger.error(f'日志记录失败: {e}')
            return result
        return decorated_function
    return decorator

def rate_limit(max_requests=100, window=3600):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import session, request
            import time
            
            key = f'rate_limit:{request.remote_addr}:{f.__name__}'
            now = time.time()
            window_start = now - window
            
            if key not in session:
                session[key] = []
            
            requests = [t for t in session[key] if t > window_start]
            session[key] = requests
            
            if len(requests) >= max_requests:
                flash('请求过于频繁，请稍后再试', 'danger')
                return redirect(url_for('index'))
            
            session[key].append(now)
            return f(*args, **kwargs)
        return decorated_function
    return decorator
